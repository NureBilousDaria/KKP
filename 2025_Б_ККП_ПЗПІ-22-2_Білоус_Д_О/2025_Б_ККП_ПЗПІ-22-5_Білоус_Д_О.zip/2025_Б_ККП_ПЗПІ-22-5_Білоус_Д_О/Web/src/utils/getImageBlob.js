export const getImageBlob = (file) => {
    const reader = new FileReader();

    reader.onload = () => {

    }

}