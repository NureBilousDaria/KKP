package com.example.tasksyncmobileapp.model.response

import com.example.tasksyncmobileapp.model.Company

data class CompanyResponse(
    val company: Company
)
