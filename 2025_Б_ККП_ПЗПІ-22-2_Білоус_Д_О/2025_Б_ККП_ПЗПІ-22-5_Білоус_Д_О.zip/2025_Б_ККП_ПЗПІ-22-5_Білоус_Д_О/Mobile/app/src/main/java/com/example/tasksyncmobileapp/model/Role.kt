package com.example.tasksyncmobileapp.model

data class Role (
    val id: Int,
    val roleTitle: String,
    val description: String
)