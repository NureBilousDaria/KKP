package com.example.tasksyncmobileapp.model

data class Education(
    val id: Int,
    val educationTitle: String,
    val description: String
)
