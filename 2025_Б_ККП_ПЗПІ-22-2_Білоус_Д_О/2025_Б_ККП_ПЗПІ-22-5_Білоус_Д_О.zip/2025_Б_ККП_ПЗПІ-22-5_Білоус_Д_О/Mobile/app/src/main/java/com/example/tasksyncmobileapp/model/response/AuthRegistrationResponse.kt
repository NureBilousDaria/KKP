package com.example.tasksyncmobileapp.model.response

data class AuthRegistrationResponse(
    val token: String
)
