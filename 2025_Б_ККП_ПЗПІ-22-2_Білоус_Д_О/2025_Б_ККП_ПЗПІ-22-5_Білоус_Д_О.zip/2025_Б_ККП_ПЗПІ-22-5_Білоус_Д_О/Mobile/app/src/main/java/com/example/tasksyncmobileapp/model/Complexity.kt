package com.example.tasksyncmobileapp.model

data class Complexity(
    val id: Int,
    val complexityTitle: String,
    val evaluation: Int
)
