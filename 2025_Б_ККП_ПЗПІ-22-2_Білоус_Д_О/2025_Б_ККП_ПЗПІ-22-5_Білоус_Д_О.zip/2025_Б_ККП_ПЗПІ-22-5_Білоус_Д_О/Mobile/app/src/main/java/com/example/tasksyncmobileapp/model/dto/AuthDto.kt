package com.example.tasksyncmobileapp.model.dto

data class AuthDto(
    val email: String,
    val password: String
)
