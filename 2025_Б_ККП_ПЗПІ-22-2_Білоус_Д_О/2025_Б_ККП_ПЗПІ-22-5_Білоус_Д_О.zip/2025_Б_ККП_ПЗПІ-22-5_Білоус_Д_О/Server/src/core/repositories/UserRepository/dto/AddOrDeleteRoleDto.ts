export default class AddOrDeleteRoleDto {
    constructor(
        public readonly roleTitle: string
    ) {}
}