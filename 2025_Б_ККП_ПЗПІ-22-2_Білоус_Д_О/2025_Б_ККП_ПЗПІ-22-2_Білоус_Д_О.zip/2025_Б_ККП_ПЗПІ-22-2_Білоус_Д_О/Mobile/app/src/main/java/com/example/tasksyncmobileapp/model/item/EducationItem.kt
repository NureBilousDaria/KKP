package com.example.tasksyncmobileapp.model.item

data class EducationItem(
    val id: Int,
    val educationTitle: String
)
