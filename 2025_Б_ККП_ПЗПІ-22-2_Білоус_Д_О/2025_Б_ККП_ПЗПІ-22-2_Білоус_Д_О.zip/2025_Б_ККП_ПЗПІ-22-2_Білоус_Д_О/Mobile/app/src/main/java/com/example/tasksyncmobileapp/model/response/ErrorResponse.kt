package com.example.tasksyncmobileapp.model.response

data class ErrorResponse(
    val message: String
)
