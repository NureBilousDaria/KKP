package com.example.tasksyncmobileapp.model.dto

data class AddDeleteEmployeeFromActivityDto(
    val userId: Int
)
