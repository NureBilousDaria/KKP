package com.example.tasksyncmobileapp.model.dto

data class AddDeleteRoleDto (
    val roleTitle: String
)