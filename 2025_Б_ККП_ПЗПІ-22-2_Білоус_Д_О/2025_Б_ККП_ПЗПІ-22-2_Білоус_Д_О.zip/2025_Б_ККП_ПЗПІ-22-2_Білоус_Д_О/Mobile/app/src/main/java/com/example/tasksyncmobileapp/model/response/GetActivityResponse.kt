package com.example.tasksyncmobileapp.model.response

import com.example.tasksyncmobileapp.model.Activity

data class GetActivityResponse (
    val activity: Activity
)