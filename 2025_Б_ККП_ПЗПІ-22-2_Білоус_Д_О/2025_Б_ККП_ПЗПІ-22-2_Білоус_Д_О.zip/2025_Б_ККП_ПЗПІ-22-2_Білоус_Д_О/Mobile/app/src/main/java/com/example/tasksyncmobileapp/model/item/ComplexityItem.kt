package com.example.tasksyncmobileapp.model.item

data class ComplexityItem(
    val id: Int,
    val complexityTitle: String
)
