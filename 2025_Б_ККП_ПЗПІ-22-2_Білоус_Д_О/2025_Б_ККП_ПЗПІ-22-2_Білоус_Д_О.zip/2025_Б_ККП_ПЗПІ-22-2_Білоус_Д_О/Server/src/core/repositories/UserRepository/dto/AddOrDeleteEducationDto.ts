export default class AddOrDeleteEducationDto {
    constructor(
       public readonly educationTitle: string
    ) {}
}