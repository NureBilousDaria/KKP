export default class CreateEducationDto {
    constructor(
        public readonly educationTitle: string,
        public readonly description: string,

    ) {}
}