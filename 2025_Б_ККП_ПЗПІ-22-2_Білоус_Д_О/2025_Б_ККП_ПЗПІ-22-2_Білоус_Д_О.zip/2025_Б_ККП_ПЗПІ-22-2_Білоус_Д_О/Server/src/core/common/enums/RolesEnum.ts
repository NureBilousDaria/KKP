enum UserRole {
    ADMIN = 'SYSTEM-ADMIN',
    USER = 'USER',
    COMPANY_ADMIN = 'COMPANY-ADMIN',
    SUBSCRIBER = 'SUBSCRIBER'
}

export default UserRole;