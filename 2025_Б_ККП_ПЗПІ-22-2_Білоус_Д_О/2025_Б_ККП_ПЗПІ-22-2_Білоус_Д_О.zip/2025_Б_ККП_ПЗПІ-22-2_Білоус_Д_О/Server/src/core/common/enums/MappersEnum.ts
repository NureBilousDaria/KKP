enum Mappers {
    ActivityMapper = 'ActivityMapper',
    CompanyMapper = 'CompanyMapper',
    ComplexityMapper = 'ComplexityMapper',
    EducationMapper = 'EducationMapper',
    RoleMapper = 'RoleMapper',
    ScannerHistoryMapper = 'ScannerHistoryMapper',
    ScannerMapper = 'ScannerMapper',
    UserMapper = 'UserMapper'
}

export default Mappers;