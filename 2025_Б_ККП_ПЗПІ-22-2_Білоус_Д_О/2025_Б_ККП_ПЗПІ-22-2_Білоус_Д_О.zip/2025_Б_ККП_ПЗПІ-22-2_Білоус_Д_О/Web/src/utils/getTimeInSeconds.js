export function getTimeInSeconds(hours, minutes) {
    return (hours * 3600) + (minutes * 60);
}

